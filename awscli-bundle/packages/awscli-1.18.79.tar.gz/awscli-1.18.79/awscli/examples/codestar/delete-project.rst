**To delete a project**

The following ``delete-project`` example deletes the specified project. ::

    aws codestar delete-project \
        --project-id my-project

Output::

    {
        "projectArn": "arn:aws:codestar:us-east-2:123456789012:project/my-project"
    }
