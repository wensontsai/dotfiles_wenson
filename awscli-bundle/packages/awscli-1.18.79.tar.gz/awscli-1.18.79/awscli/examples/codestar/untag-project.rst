**To remove a tag from a project**

The following ``untag-project`` example removes any tag with a key name of ``Team`` from the specifiec project. ::

    aws codestar untag-project \
        --id my-project \
        --tags Team

This command produces no output.
